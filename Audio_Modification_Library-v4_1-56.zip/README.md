# Audio Modification Library
AudModLib is a compatibility framework that allows the seamless integration of multiple audio mods for Magisk installs. Enables supported audio mods to share the same needed files sudo as audio_effects. [More details in support thread](https://forum.xda-developers.com/apps/magisk/mod-audio-modification-library-t3745466).<br/>
To uninstall, REMOVE WITH MAGISK MANAGER

## Changelog
* See [Changelog](changelog.md)

## Source Code
* Module [GitHub](https://github.com/Zackptg5/Audio-Modification-Library)
